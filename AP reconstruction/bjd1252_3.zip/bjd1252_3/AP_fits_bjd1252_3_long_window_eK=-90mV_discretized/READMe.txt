We optimized 10 individual action potentials (AP0-9) for each axon. 
Optimization was initiated from four different parameter sets. 
The folders labeled 'set_1' to 'set_4' contain these individual optimizations. 
Each folder contains the same model, differing only in the initial parameters used for optimization.

The optimization process begins with 'init.hoc,' which performs the fitting for all ten APs and generates an output folder (output1-4). 
This folders include the simulated measured, local, and native AP waveforms, as well as an output file containing the model's channel parameters, fitting error, and calculated AP parameters.

This approach resulted in four different sets of conductance parameters for each AP. 
Among these, the one with the smallest error was considered the optimal fit. Optimal AP vaveforms were collected in the best_fit_APs folder
We then averaged the 10 optimal parameter sets to describe the sodium and potassium currents underlying the recorded spike waveforms.

We used the averaged parameter set to generate the final native AP waveform and the underlying Na and K currents (AP_current_generator folder).
