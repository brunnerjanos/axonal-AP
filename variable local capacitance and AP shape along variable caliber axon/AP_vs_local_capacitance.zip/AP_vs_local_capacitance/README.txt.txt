brunner 2024 at KOKI
............................................

simulation to determine AP parameters along a fully reconstructed mossy fiber.

starts with init_python.py

- The simulation takes only a few minutes on a laptop
- the model neuron is active now 
- An AP will be triggered at the soma. At each axonal position, NEURON will record the Vm and the AP related calcium current.
