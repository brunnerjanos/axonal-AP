from neuron import h
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scalebars #taken from https://gist.github.com/dmeliza/3251476
import customtkinter as ctk


h.load_file("main_CC.hoc")



h.psection()

ICl=h.IClamp(h.soma(.5))
ICl.dur=2
ICl.amp=.75

h.v_init=-80
h.tstop=8.5
h.dt=.004


def Ica_analysis(Icatrace,peakindex):

    bl_trace_=Icatrace[0:int(.1/h.dt)]  
    bl=np.mean(bl_trace_)
    print (bl)
    Icatrace=Icatrace-bl
    peak=np.min(Icatrace)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms


    Ica_trace_=Icatrace[peakindex:peakindex+int(0.6/h.dt)]
    area_o6=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms

   
    Ica_trace_=Icatrace[peakindex:peakindex+int(1/h.dt)]
    area_1=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms

    Ica_trace_=Icatrace[peakindex:peakindex+int(1.5/h.dt)]
    area_1o5=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms

    Ica_trace_=Icatrace[peakindex:peakindex+int(2/h.dt)]
    area_2=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms

    Ica_trace_=Icatrace[peakindex:peakindex+int(3/h.dt)]
    area_3=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms

    Ica_trace_=Icatrace[peakindex:peakindex+int(5/h.dt)]
    area_5=np.trapz(Ica_trace_, dx=h.dt)*1e3 #1e3 is for conversion to pA*ms instead of nA*ms  

    return peak, area_o6, area_1, area_1o5, area_2, area_3, area_5




def AP_analysis (Vm_trace,Ica_trace=None):
    AP_peak=np.max(Vm_trace)
    PeakIndex=np.argmax(Vm_trace)
    ecatr_mV=np.flip(Vm_trace)
    PeakIndex_=-1
    AP_peak_=-1
    for i in range(1, len(ecatr_mV)-1):
        if (ecatr_mV[i]>=0):
            if (ecatr_mV[i-1] > ecatr_mV[i]):
                PeakIndex_=len(ecatr_mV)-i
                AP_peak_=ecatr_mV[i-1]
                break     
    for i in range(1, len(ecatr_mV)-1):
        if (ecatr_mV[i]>=-30):
            RightIndex_30=len(ecatr_mV)-i
            break
    for i in range(1, len(ecatr_mV)-1):
        if (ecatr_mV[i]>=-20):
            RightIndex_20=len(ecatr_mV)-i
            break 
    for i in range(1, len(ecatr_mV)-1):
        if (ecatr_mV[i]>=-10):
            RightIndex_10=len(ecatr_mV)-i
            break                     
    for i in range(1, len(Vm_trace)-1):        
        if (Vm_trace[i]>=-30):
            LeftIndex_30=i
            break             
    for i in range(1, len(Vm_trace)-1):        
        if (Vm_trace[i]>=-20):
            LeftIndex_20=i                
            break 
    for i in range(1, len(Vm_trace)-1):        
        if (Vm_trace[i]>=-10):
            LeftIndex_10=i        
            break 
        
    width_30=(RightIndex_30-LeftIndex_30)*h.dt
    width_20=(RightIndex_20-LeftIndex_20)*h.dt
    width_10=(RightIndex_10-LeftIndex_10)*h.dt    
    
    halfRep=(RightIndex_20-PeakIndex)*h.dt

    Vm_trace_=Vm_trace[np.argmax(Vm_trace):np.argmax(Vm_trace)+int(0.6/h.dt)]+79.995
    area_o6=np.trapz(Vm_trace_, dx=h.dt)
    
    Vm_trace_=Vm_trace[np.argmax(Vm_trace):np.argmax(Vm_trace)+int(0.8/h.dt)]+79.995
    area_o8=np.trapz(Vm_trace_, dx=h.dt)

    Vm_trace_=Vm_trace[np.argmax(Vm_trace):np.argmax(Vm_trace)+int(1/h.dt)]+79.995
    area_1=np.trapz(Vm_trace_, dx=h.dt)    

    Vm_trace_=Vm_trace[np.argmax(Vm_trace):np.argmax(Vm_trace)+int(1.25/h.dt)]+79.995
    area_1o25=np.trapz(Vm_trace_, dx=h.dt)    

    Vm_trace_=Vm_trace[np.argmax(Vm_trace):np.argmax(Vm_trace)+int(1.5/h.dt)]+79.995
    area_1o5=np.trapz(Vm_trace_, dx=h.dt)        


    Vm_trace_=Vm_trace[np.argmax(Vm_trace)+14:np.argmax(Vm_trace)+14+130]+70
    area=np.trapz(Vm_trace_, dx=h.dt)
    Vm_trace__=Vm_trace[PeakIndex_+14:PeakIndex_+14+130]+70
    area_=np.trapz(Vm_trace__, dx=h.dt)
    area__=np.sum(Vm_trace[PeakIndex_+14:PeakIndex_+14+130]+70)/250 


    dVdtTrace=np.diff(Vm_trace)/h.dt

    dVdt_max=np.max(dVdtTrace)
    dVdt_min=np.min(dVdtTrace)


    Ica_peak, ICa_area_o6, ICa_area_1, ICa_area_1o5, ICa_area_2, ICa_area_3, ICa_area_5  = Ica_analysis(Ica_trace,PeakIndex)
    Ica_peak_, ICa_area_o6_, ICa_area_1_, ICa_area_1o5_, ICa_area_2_, ICa_area_3_, ICa_area_5_  = Ica_analysis(Ica_trace,PeakIndex_)     

    return dVdt_max, dVdt_min, AP_peak_, AP_peak, area, width_10, width_20, width_30, halfRep, area_o6, area_o8, area_1, area_1o25, area_1o5,\
    Ica_peak, ICa_area_o6, ICa_area_1, ICa_area_1o5, ICa_area_2, ICa_area_3, ICa_area_5 , \
    Ica_peak_, ICa_area_o6_, ICa_area_1_, ICa_area_1o5_, ICa_area_2_, ICa_area_3_, ICa_area_5_,PeakIndex_



Vm_traces=[]
Ica_traces=[]
res1,res2,res3,res4,res5,res6,res7,res8,res9,res10,res11,res12,res13,res14=[],[],[],[],[],[],[],[],[],[],[],[],[],[]
res15,res16,res17,res18,res19,res20,res21,res22,res23,res24,res25,res26,res27=[],[],[],[],[],[],[],[],[],[],[],[],[]

results=[]
secRef = h.SectionRef(h.axon[463])

while secRef.has_parent():
    #print(secRef.sec.gkbar_hh_mod)

    spacing=np.linspace(0,1, num=secRef.sec.nseg+2)
    spacing=spacing[1:]
    for loci in reversed(spacing): 
        #print(secRef.sec(loci)) 

        Vm_traces.append(h.Vector().record(secRef.sec(loci)._ref_v))
        Ica_traces.append(h.Vector().record(secRef.sec(loci)._ref_ica))
        res1.append(h.distance(h.soma(0.5), (secRef.sec(loci))))
        res2.append(secRef.sec(loci).diam)  
  
    secRef = h.SectionRef(secRef.parent)


for sec in h.allsec():
    sec.insert ('capq')
    sec.gbar_capq=.00065
    sec.insert ('capq')
    sec.gbar_can=.00025
    sec.insert ('capq')
    sec.gbar_car=.0001

h.run() 

for n in range(0, (len(Vm_traces))):

    VCvec=np.array(Vm_traces[n])
    ICavec=np.array(Ica_traces[n])
    dVdt_max_, dVdt_min_, AP_peak__, AP_peak_abs, area___, width_10_, width_20_, width_30_, halfRep_, area_o6_, area_o8_, area_1_, area_1o25_, area_1o5_, \
    ica_peak, iCa_area_o6, iCa_area_1, iCa_area_1o5, iCa_area_2, iCa_area_3, iCa_area_5, \
    ica_peak_, iCa_area_o6_, iCa_area_1_, iCa_area_1o5_, iCa_area_2_, iCa_area_3_, iCa_area_5_,lastPeakIndex=AP_analysis(VCvec,ICavec)
    
    
    res3.append(dVdt_max_) 
    res4.append(dVdt_min_) 
    res5.append(AP_peak__) 
    res6.append(AP_peak_abs)    
    res7.append(area___) 
    res8.append(width_10_)     
    res9.append(width_20_) 
    res10.append(width_30_) 
    res11.append(halfRep_) 
    res12.append(ica_peak) 
    res13.append(iCa_area_o6)
    res14.append(iCa_area_1)
    res15.append(iCa_area_1o5)
    res16.append(iCa_area_2)
    res17.append(iCa_area_3)
    res18.append(iCa_area_5)
    res19.append(ica_peak_)
    res20.append(iCa_area_o6_)
    res21.append(iCa_area_1_)
    res22.append(iCa_area_1o5_)
    res23.append(iCa_area_2_)
    res24.append(iCa_area_3_)
    res25.append(iCa_area_5_)
    res26.append(lastPeakIndex)


v_tr10=np.array(Vm_traces[1214]) #axon[322](0.390244)
v_tr9=np.array(Vm_traces[1194]) #axon[322](0.878049)
v_tr8=np.array(Vm_traces[1176]) #axon[325](0.141304)
v_tr7=np.array(Vm_traces[1155]) #axon[325](0.369565)
v_tr6=np.array(Vm_traces[1135]) #axon[325](0.576087)
v_tr5=np.array(Vm_traces[1115]) #axon[325](0.804348)
v_tr4=np.array(Vm_traces[1096]) #axon[331](0.0434783)
v_tr3=np.array(Vm_traces[1087]) #axon[331](0.434783)
v_tr2=np.array(Vm_traces[1075]) #axon[331](0.956522)
v_tr1=np.array(Vm_traces[1067]) #axon[337](0.259259)
v_tr0=np.array(Vm_traces[1056]) #axon[337](0.666667)


i_tr10=np.array(Ica_traces[1214])*1e3 #axon[322](0.390244)
i_tr9=np.array(Ica_traces[1194])*1e3 #axon[322](0.878049)
i_tr8=np.array(Ica_traces[1176])*1e3 #axon[325](0.141304)
i_tr7=np.array(Ica_traces[1155])*1e3 #axon[325](0.369565)
i_tr6=np.array(Ica_traces[1135])*1e3 #axon[325](0.576087)
i_tr5=np.array(Ica_traces[1115])*1e3 #axon[325](0.804348)
i_tr4=np.array(Ica_traces[1096])*1e3 #axon[331](0.0434783)
i_tr3=np.array(Ica_traces[1087])*1e3 #axon[331](0.434783)
i_tr2=np.array(Ica_traces[1075])*1e3 #axon[331](0.956522)
i_tr1=np.array(Ica_traces[1067])*1e3 #axon[337](0.259259)
i_tr0=np.array(Ica_traces[1056])*1e3 #axon[337](0.666667)



for sec in h.allsec():
    sec.gbar_capq=0
    sec.gbar_can=0
    sec.gbar_car=0

h.run() 

for n in range(0, (len(Vm_traces))):
    VCvec=np.array(Vm_traces[n])
    ICavec=np.array(Ica_traces[n])
    dVdt_max_, dVdt_min_, AP_peak__, AP_peak_abs, area___, width_10_, width_20_, width_30_, halfRep_, area_o6_, area_o8_, area_1_, area_1o25_, area_1o5_, \
    ica_peak, iCa_area_o6, iCa_area_1, iCa_area_1o5, iCa_area_2, iCa_area_3, iCa_area_5, \
    ica_peak_, iCa_area_o6_, iCa_area_1_, iCa_area_1o5_, iCa_area_2_, iCa_area_3_, iCa_area_5_,lastPeakIndex=AP_analysis(VCvec,ICavec)
    
    res27.append(area___)



s0=pd.Series(res1,name='somatic_distance')
s1=pd.Series(res2,name='diameter')
s3=pd.Series(res3,name='dVdt_max')
s4=pd.Series(res4,name='dVdt_min')
s5=pd.Series(res5,name='AP_peak')
s6=pd.Series(res6,name='AP_peak_abs')
s7=pd.Series(res7,name='AP_area')
s8=pd.Series(res8,name='width_10_')
s9=pd.Series(res9,name='width_20_')
s10=pd.Series(res10,name='width_30_')
s11=pd.Series(res11,name='halfRep_')
s12=pd.Series(res12,name='peak calcum current')
s13=pd.Series(res13,name='I_calcium_area_0.6ms')
s14=pd.Series(res14,name='I_calcium_area_1ms')
s15=pd.Series(res15,name='I_calcium_area_1o5ms')
s16=pd.Series(res16,name='I_calcium_area_2ms')
s17=pd.Series(res17,name='I_calcium_area_3ms')
s18=pd.Series(res18,name='I_calcium_area_5ms')
s19=pd.Series(res19,name='peak calcum current_')
s20=pd.Series(res20,name='I_calcium_area_0.6ms_')
s21=pd.Series(res21,name='I_calcium_area_1ms_')
s22=pd.Series(res22,name='I_calcium_area_1o5ms_')
s23=pd.Series(res23,name='I_calcium_area_2ms_')
s24=pd.Series(res24,name='I_calcium_area_3ms_')
s25=pd.Series(res25,name='I_calcium_area_5ms_')
s26=pd.Series(res26,name='lastpeakindex')
s27=pd.Series(res27,name='area_woCalcium')
df = pd.concat([s0, s1,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27], axis=1).reset_index()

df.to_csv('output.csv', index=False)  

def defineShift(trace,refTrace,direction=True):
    if direction == True:
        shiftIndex=np.argmax(refTrace)-np.argmax(trace)
    else:
        shiftIndex=np.argmin(refTrace)-np.argmin(trace)  
    return shiftIndex

def peakAlign(TraceToShift, shiftIndex, size):          
    shTrace=np.insert(TraceToShift, 0, np.zeros(shiftIndex))
    shTrace=shTrace[:int(size/h.dt)] 
    return shTrace



topfig, ax = plt.subplot_mosaic([[1, 3],
                                [2, 4]])

color1 = 'tab:red'

TimeVec=np.linspace(0, int(len(v_tr10)*h.dt), int(len(v_tr10)), endpoint=True, retstep=False, dtype=None, axis=0) 


color0 = '#00008B'


ax[1] = plt.subplot(3, 2, 1)
plt.xlim(3, 6)

ax[1].set_ylabel('Vm (mV)')
ax[1].plot(TimeVec, v_tr10, color=color0)
ax[1].plot(TimeVec, v_tr9, color=color0)
ax[1].plot(TimeVec, v_tr8, color=color0)
ax[1].plot(TimeVec, v_tr7, color=color0)
ax[1].plot(TimeVec, v_tr6, color=color0)
ax[1].plot(TimeVec, v_tr5, color=color0)
ax[1].plot(TimeVec, v_tr4, color=color0)
ax[1].plot(TimeVec, v_tr3, color=color0)
ax[1].plot(TimeVec, v_tr2, color=color1)#LMFB
ax[1].plot(TimeVec, v_tr1, color=color0)
ax[1].plot(TimeVec, v_tr0, color=color0)



color0 = 'tab:gray'

ax[2] = plt.subplot(3, 2, 3)
plt.xlim(3, 6)
ax[2] .set_xlabel('time (ms)')
ax[2] .set_ylabel('calcium current (pA)')
ax[2] .plot(TimeVec,i_tr10, color=color0)
ax[2] .plot(TimeVec,i_tr9, color=color0)
ax[2] .plot(TimeVec,i_tr8, color=color0)
ax[2] .plot(TimeVec,i_tr7, color=color0)
ax[2] .plot(TimeVec,i_tr6, color=color0)
ax[2] .plot(TimeVec,i_tr5, color=color0)
ax[2] .plot(TimeVec,i_tr4, color=color0)
ax[2] .plot(TimeVec,i_tr3, color=color0)
ax[2] .plot(TimeVec,i_tr2, color=color1)#LMFB
ax[2] .plot(TimeVec,i_tr1, color=color0)
ax[2] .plot(TimeVec,i_tr0, color=color0)


size=6
TimeVec=np.linspace(0, int(size), int(size/h.dt), endpoint=True, retstep=False, dtype=None, axis=0) 


color0 = '#00008B'


ax[3]  = plt.subplot(3, 2, 2)
plt.xlim(4, 5)

ax[3].plot(TimeVec, peakAlign(v_tr10,defineShift(v_tr10,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr9,defineShift(v_tr9,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr8,defineShift(v_tr8,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr7,defineShift(v_tr7,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr6,defineShift(v_tr6,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr5,defineShift(v_tr5,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr4,defineShift(v_tr4,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr3,defineShift(v_tr3,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr2,defineShift(v_tr2,v_tr0),size=size), color=color1)#LMFB
ax[3].plot(TimeVec, peakAlign(v_tr1,defineShift(v_tr1,v_tr0),size=size), color=color0)
ax[3].plot(TimeVec, peakAlign(v_tr0,defineShift(v_tr0,v_tr0),size=size), color=color0)

ax[3].set_title('peak-aligned,zoomed-in')

scalebars.add_scalebar(ax[3], {"labelx": "ms", "labely": "mV"})
color0 = 'tab:gray'

ax[4] = plt.subplot(3, 2, 4)
plt.xlim(3.9, 5)
ax[4].set_xlabel('time (ms)')
ax[4].plot(TimeVec, peakAlign(i_tr10,defineShift(v_tr10,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr9,defineShift(v_tr9,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr8,defineShift(v_tr8,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr7,defineShift(v_tr7,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr6,defineShift(v_tr6,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr5,defineShift(v_tr5,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr4,defineShift(v_tr4,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr3,defineShift(v_tr3,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr2,defineShift(v_tr2,v_tr0),size=size), color=color1)#LMFB
ax[4].plot(TimeVec, peakAlign(i_tr1,defineShift(v_tr1,v_tr0),size=size), color=color0)
ax[4].plot(TimeVec, peakAlign(i_tr0,defineShift(v_tr0,v_tr0),size=size), color=color0)
scalebars.add_scalebar(ax[4])



data = pd.read_csv('local_capactiance.txt',sep=' ',header=0) 
#note that the diameter in the l.1186 was modified from 1.092022082 to the adjacent off-path located LMFB data (2.95)
print(data['local_capacitance(pF)'])

middlefig, axm = plt.subplot_mosaic([[0, 0],
                                    [1, 1],
                                    [2, 2],
                                    [3, 3],
                                    [4, 4],
                                    [5, 5]],sharex=True)


color0 = '#00008B'

axm[0].plot(data['somatic_distance'], data['diameter'],color=color0)
axm[0].title.set_text('diameter (microns)')
axm[0].set_yticks([0,1,2,5])
axm[1].plot(data['somatic_distance'], data['local_capacitance(pF)'],color=color0)
axm[1].title.set_text('local capacitance (pF)')
axm[1].set_yticks([0, 0.5,1])
axm[2].plot(data['somatic_distance'],s9,color=color0)
axm[2].title.set_text('AP half-width (ms)')
axm[2].set_yticks([0.2,0.4,0.6])
axm[3].plot(data['somatic_distance'],s7,color=color0)
axm[3].title.set_text('AP area (mV/ms)')
axm[3].set_yticks([15,30,45])


icaPlot=s15 #s15is ica_area105
normica=(np.divide(icaPlot, np.average(icaPlot)))*100 
axm[4].plot(data['somatic_distance'],normica,color=color0)
axm[4].title.set_text('calcium influx (normalized,%)')
axm[4].set_yticks([90,100,110,120])

release=(np.divide(np.power(abs(icaPlot), 2.5),np.average(np.power(abs(icaPlot), 2.5))))*100  #assuming 2.5 power relationship between calcium influx and the release
axm[5].plot(data['somatic_distance'],release,color=color0)       
axm[5].title.set_text('release rate (normalized,%)')
axm[5].set_yticks([80,100,120,140])

plt.xlim(100,1700) 
middlefig.tight_layout() 






bottomfig, axb = plt.subplot_mosaic([[0, 0],
                            [0, 0]],sharex=True)
axb[0]=plt.scatter(data['local_capacitance(pF)'],s27,s=8, facecolors='none',edgecolors='darkblue')

axb[0].axes.set_yticks([0,10,20,30])
plt.show()
