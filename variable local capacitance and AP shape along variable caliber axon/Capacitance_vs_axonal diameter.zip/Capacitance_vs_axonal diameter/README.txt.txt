brunner 2024 at KOKI
............................................

simulation to determine local capacitance along a fully reconstructed mossy fiber. It simulates a simplified axonal patch-clamp experiment at many different axonal locations from which
we can calculate the local capacitance as in the real experiments

starts with init_python.py

- The simulation takes about 1 hour on a laptop
- the model neuron is passive here (e_pas=0, g_pas=2e-5, cm=1, Ra=150) 
- At each axonal position, NEURON will record the clamp current evoked by a -20 mV voltage step. Python do a biexponential fit of the recorded signal from which the fastest component
is assumed to represent the local capacitance. 
- For capacitance calculation we used the following eqn.: C_local(pF)=[I_ampl(pA)*Tau(ms)]/V_step(mV)     
- output of the simualtion is the 'output.csv' file that contains the somatic distance and local diameter values at each simulated recording together with the
parameters of the fits, the calculated local capacitance, and the calculated local input resistance.
