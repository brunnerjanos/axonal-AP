from neuron import h
import numpy as np
import pandas as pd
import scipy.optimize
import scipy.signal
import matplotlib.pyplot as plt
import time


'''
simulation to determine local capacitance along a fully reconstructed mossy fiber. It simulates a simplified axonal patch-clamp experiment at many different axonal locations from which
we can calculate the local capacitance as in the real experiments
- The simulation takes about 1 hour on a laptop
- the model neuron is passive here (e_pas=0, g_pas=2e-5, cm=1, Ra=150) 
- At each axonal position, NEURON will record the clamp current evoked by a -20 mV voltage step. Python do a biexponential fit of the recorded signal from which the fastest component
is assumed to represent the local capacitance. 
- For capacitance calculation we used the following eqn.: C_local(pF)=[I_ampl(pA)*Tau(ms)]/V_step(mV)     
- output of the simualtion is the 'output.csv' file that contains the somatic distance and local diameter values at each simulated recording together with the
parameters of the fits, the calculated local capacitance, and the calculated local input resistance.
BRUNNER_@t_KOKI
'''

h.load_file("VC_cap.hoc") #initiate the hoc files

def biExp(x, m, n, t0, t1, b):
    return (m * np.exp(-t0 * x) +  n * np.exp(-t1 * x))+ b 
	
def DoThatBiFit(xs,ys,EndOfFitWindow):#biexponential fit, similar to what I use in the Clampfit
    #outputs are the two Taus and their ampitude values together with the magnitude of the steady state component
    p0 = -50, -50, .1, 1, -10

    try:
        params, cv = scipy.optimize.curve_fit(biExp, xs[:int(EndOfFitWindow/h.dt)], ys[:int(EndOfFitWindow/h.dt)], p0, method='lm', maxfev=10000)
        m, n, t0, t1, b = params
        if t0 > t1: #to make sure that output tau2/amp2 will be the faster component
            amp2=n
            tau2=1/t1
            amp1=m
            tau1=1/t0
            ss_val=b  
        else:
            amp1=n
            tau1=1/t1
            amp2=m
            tau2=1/t0
            ss_val=b  

        print (amp2,tau2,amp1,tau1, ss_val)
        return amp2,tau2,amp1,tau1, ss_val   
        
    except RuntimeError:
        return -1,-1,-1,-1,-1
     


h.psection() #Print info about the accessed section to check that settings are fine 

res1,res2,res3,res4,res5,res6,res7,res8,res9=[],[],[],[],[],[],[],[],[]





secRef = h.SectionRef(h.axon[463]) #most distal section of the mossy fiber

start = time.time()

while secRef.has_parent(): #puts the simulated experiment on each segment in all the sections between the most distal section and the soma
    spacing=np.linspace(0,1, num=secRef.sec.nseg+2)
    spacing=spacing[1:]
    for loci in reversed(spacing):  
        VCl=h.SEClamp(secRef.sec(loci))   #built-in VC with experimentally used params and realistic Raccess
        VCl.rs=100
        VCl.dur1=2
        VCl.amp1=0
        VCl.dur2=18
        VCl.amp2=-20
        vecVC=h.Vector()
        vecVC.record(VCl._ref_i)
        h.finitialize(0)
        h.run()
        VCvec=np.array(vecVC)
        VCvec=VCvec*1000   #conversion of clamp current from nA to pA     
        
        VCvecTime=np.linspace(0, (len(VCvec)-1)*h.dt, num=len(VCvec), endpoint=True, retstep=False, dtype=None, axis=0) #time axis for filtering the clamp current

        bfilt=scipy.signal.bessel(8, 16, btype='low', analog=False, output='sos', norm='phase', fs=1/h.dt)#8 pole bessel filter with normalized cutoff frequency of 16kHz

        filtTrace = scipy.signal.sosfilt(bfilt, VCvec)
        filtTrace=filtTrace[np.argmin(filtTrace):]# trace starts from the peak now 
        
        amp2_,tau2_,amp1_,tau1_, ss_val_=DoThatBiFit(VCvecTime,filtTrace,5)        
        
        res1.append(h.distance(h.soma(0.5), (secRef.sec(loci))))
        res2.append(secRef.sec(loci).diam)  
        res3.append(amp2_) 
        res4.append(tau2_) 
        res5.append(amp1_) 
        res6.append(tau1_) 
        res7.append(ss_val_) 
        res8.append(VCl.amp2/ss_val_)       
        res9.append(amp1_*tau1_/VCl.amp2)
    secRef = h.SectionRef(secRef.parent)


s0=pd.Series(res1,name='somatic_distance')
s1=pd.Series(res2,name='diameter')
s3=pd.Series(res3,name='peak_slow_fitted')
s4=pd.Series(res4,name='tau_slow_fitted')
s5=pd.Series(res5,name='peak_fast_fitted')
s6=pd.Series(res6,name='tau_fast_fitted')
s7=pd.Series(res7,name='steady state current')
s8=pd.Series(res8,name='Rin_VC(GOhm)')
s9=pd.Series(res9,name='local capacitance(pF)')

df = pd.concat([s0, s1,s3,s4,s5,s6,s7,s8,s9], axis=1).reset_index()

df.to_csv('output.csv', index=False)  


#plot the results

fig, ax0 = plt.subplots()

color = 'tab:red'

ax0.set_xlabel('somatic distance (micron)')
ax0.set_ylabel('diameter')
ax0.plot(res1, res2, color=color)
ax0.tick_params(axis='y', labelcolor=color)

ax1 = ax0.twinx() 
plt.xlim(100, 1700)
color = 'tab:blue'
ax1.set_ylabel('fitted local capacitance (pF)')
ax1.plot(res1, res9, color=color)
ax1.tick_params(axis='y', labelcolor=color)

fig.tight_layout()

plt.savefig('Diam_Cap_vs_SomaDistance.pdf')

end = time.time()
print('elsped time:', end - start, ' seconds ')

plt.show()

